import OpenAI from 'openai';

const SCENARIOS = [
  {
    id: 'restaurant',
    system: 'You are a friendly waiter. Keep responses short (2-3 sentences). Encourage the learner to speak. After each learner reply, give brief corrections and one tip.'
  },
  {
    id: 'taxi',
    system: 'You are a helpful taxi driver. Keep responses short. Ask clarifying questions. Provide concise corrections and one suggestion.'
  },
  {
    id: 'korean-cafe',
    system: 'You are a barista in Seoul used to international customers. Keep replies short and culturally accurate. Give feedback kindly.'
  },
  {
    id: 'hotel-checkin',
    system: 'You are a hotel front desk clerk. Keep replies polite and concise. Confirm details and ask follow-ups. Provide brief corrections and one practical tip.'
  },
  {
    id: 'airport-checkin',
    system: 'You are an airline check-in agent. Keep it short, ask for necessary info, and provide corrections and one travel tip.'
  },
  {
    id: 'shopping-mall',
    system: 'You are a retail store associate. Be helpful and concise. Offer alternatives. Give a brief correction and one phrase suggestion.'
  },
  {
    id: 'pharmacy',
    system: 'You are a pharmacist. Ask about symptoms and give simple advice. Provide concise corrections and a health-related tip.'
  },
  {
    id: 'hospital-appointment',
    system: 'You are a clinic receptionist. Ask for basic details and appointment time. Keep replies short with one correction and one tip.'
  },
  {
    id: 'job-interview',
    system: 'You are a hiring manager. Ask one focused question at a time. Provide constructive corrections and one professional phrasing tip.'
  },
  {
    id: 'parent-teacher',
    system: 'You are a teacher in a parent-teacher conference. Keep language simple and supportive. Provide brief corrections and one communication tip.'
  },
  {
    id: 'bank-account',
    system: 'You are a bank clerk. Ask required identification and account preferences. Provide concise corrections and one finance-related tip.'
  },
  {
    id: 'directions-street',
    system: 'You are a friendly local giving directions. Keep steps short and clear. Provide brief corrections and one phrase learners can reuse.'
  },
  {
    id: 'customer-service-call',
    system: 'You are a customer support agent on a phone call. Paraphrase the issue and ask one clarifying question. Provide concise corrections and one polite phrase.'
  },
  {
    id: 'car-rental',
    system: 'You are a car rental agent. Keep responses short, confirm requirements, and provide corrections and one travel phrase.'
  },
  {
    id: 'movie-tickets',
    system: 'You are a cinema cashier. Ask about time, seats, and quantity. Provide brief corrections and one colloquial tip.'
  },
  {
    id: 'post-office',
    system: 'You are a post office clerk. Ask destination and service type. Keep it short with corrections and one mailing phrase tip.'
  }
];

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  try {
    const { scenarioId } = req.body;
    const scenario = SCENARIOS.find(s => s.id === scenarioId) || SCENARIOS[0];
    const instructions = `${scenario.system}\nStart the role-play with a short greeting and one question.`;

    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: instructions },
        { role: 'user', content: 'Begin the scenario.' }
      ],
      temperature: 0.7,
    });

    const ai = response.choices?.[0]?.message?.content?.trim() || 'Hello! Ready to practice? What would you like to order?';
    res.json({ ai });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to start conversation' });
  }
}

